package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;


import org.apache.struts2.ServletActionContext;

import com.dao.TBowenDAO;
import com.dao.TPinglunDAO;
import com.dao.TUserDAO;
import com.model.TBowen;
import com.model.TUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class bowenAction
{
	private Integer id;
	private String title;
	private String content;
	private String shijian;

	private Integer userId;
	private String del;
	
	private TBowenDAO bowenDAO;
	
	private String message;
	private String path;
	
	
	public String bowenAdd()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
		
		TBowen bowen=new TBowen();
		bowen.setTitle(title);
		bowen.setContent(content);
		bowen.setShijian(new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
		bowen.setUserId(user.getUserId());
		bowen.setDel("no");
		
		bowenDAO.save(bowen);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ϣ�����ɹ�");
		return "msg";
	}
	
	
	public String bowenMine()
	{
        Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
				
		String sql="from TBowen where del='no' and userId="+user.getUserId();
		List bowenList=bowenDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("bowenList", bowenList);
		return ActionSupport.SUCCESS;
	}
	
	public String bowenDel()
	{
		TBowen bowen=bowenDAO.findById(id);
		bowen.setDel("yes");
		bowenDAO.getHibernateTemplate().update(bowen);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ϣɾ���ɹ�");
		return "msg";
	}
	
	
	public String bowenAll()
	{
		String sql="from TBowen where del='no' order by shijian";
		List bowenList=bowenDAO.getHibernateTemplate().find(sql);
		
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("bowenList", bowenList);
		return ActionSupport.SUCCESS;
	}
	
	
	public String bowenDetailQian()
	{
        TBowen bowen=bowenDAO.findById(id);		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("bowen", bowen);
		return ActionSupport.SUCCESS;
	}
	
	public String bowenMana()
	{
		String sql="from TBowen where del='no'";
		List bowenList=bowenDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("bowenList", bowenList);
		return ActionSupport.SUCCESS;
	}


	public int getId()
	{
		return id;
	}


	public void setId(int id)
	{
		this.id = id;
	}


	public String getTitle()
	{
		return title;
	}


	public void setTitle(String title)
	{
		this.title = title;
	}


	public String getShijian()
	{
		return shijian;
	}


	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}


	public Integer getUserId()
	{
		return userId;
	}


	public void setUserId(Integer userId)
	{
		this.userId = userId;
	}


	public String getDel()
	{
		return del;
	}


	public void setDel(String del)
	{
		this.del = del;
	}


	public void setId(Integer id)
	{
		this.id = id;
	}


	public String getContent()
	{
		return content;
	}


	public void setContent(String content)
	{
		this.content = content;
	}


	public TBowenDAO getBowenDAO()
	{
		return bowenDAO;
	}


	public void setBowenDAO(TBowenDAO bowenDAO)
	{
		this.bowenDAO = bowenDAO;
	}



	public String getMessage()
	{
		return message;
	}


	public void setMessage(String message)
	{
		this.message = message;
	}


	public String getPath()
	{
		return path;
	}


	public void setPath(String path)
	{
		this.path = path;
	}
	
}
