package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.dao.TPinglunDAO;
import com.dao.TXiangceDAO;
import com.dao.TZhaopianDAO;
import com.model.TUser;
import com.model.TZhaopian;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class zhaopianAction
{
	private Integer id;
	private String title;
	private String jieshao;
	private String fujian;
	
	private String shijian;
	private Integer xiangceId;
	private Integer userId;
	private String del;
	
	private TZhaopianDAO zhaopianDAO;
	private TXiangceDAO xiangceDAO;
	private TPinglunDAO pinglunDAO;
	
	public String zhaopianAdd()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
		
		TZhaopian zhaopian=new TZhaopian();
		
		//zhaopian.setId(id);
		zhaopian.setTitle(title);
		zhaopian.setJieshao(jieshao);
		zhaopian.setFujian(fujian);
		
		zhaopian.setShijian(new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
		zhaopian.setXiangceId(xiangceId);
		zhaopian.setUserId(user.getUserId());
		zhaopian.setDel("no");
		
		zhaopianDAO.save(zhaopian);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ƭ�ϴ����");
		return "msg";
	}
	
	
	public String zhaopianMine()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
        
		String sql="from TZhaopian where del='no' and userId="+user.getUserId()+" order by xiangceId";
		List zhaopianList=zhaopianDAO.getHibernateTemplate().find(sql);
		for(int i=0;i<zhaopianList.size();i++)
		{
			TZhaopian zhaopian=(TZhaopian)zhaopianList.get(i);
			zhaopian.setXiangce(xiangceDAO.findById(zhaopian.getXiangceId()));
		}
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("zhaopianList", zhaopianList);
		
		return ActionSupport.SUCCESS;
	}
	
	
	
	public String zhaopianDel()
	{
		String sql="update TZhaopian set del='yes' where id="+id;
		zhaopianDAO.getHibernateTemplate().bulkUpdate(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ϣɾ���ɹ�");
		return "msg";
	}
	
	
	public String zhaopianMana()
	{
		Map request=(Map)ServletActionContext.getContext().get("request");
		
		String sql="from TZhaopian where del='no'";
		List zhaopianList=zhaopianDAO.getHibernateTemplate().find(sql);
		
		request.put("zhaopianList", zhaopianList);
		
		return ActionSupport.SUCCESS;
	}
	
	
	
	public String zhaopianNew()
	{
		Map request=(Map)ServletActionContext.getContext().get("request");
		
		String sql="from TZhaopian where del='no' order by shijian desc";
		List zhaopianList=zhaopianDAO.getHibernateTemplate().find(sql);
		if(zhaopianList.size()>4)
		{
			zhaopianList=zhaopianList.subList(0, 4);
		}
		request.put("zhaopianList", zhaopianList);
		
		return ActionSupport.SUCCESS;
	}
	
	

	public String zhaopianDetailQian()
	{
		Map request=(Map)ServletActionContext.getContext().get("request");
		
		TZhaopian zhaopian=zhaopianDAO.findById(id);
		zhaopian.setXiangce(xiangceDAO.findById(zhaopian.getXiangceId()));
		request.put("zhaopian", zhaopian);
		
		String sql="from TPinglun where zhaopianId="+id;
		List pinglunList=pinglunDAO.getHibernateTemplate().find(sql);
		request.put("pinglunList", pinglunList);
		
		return ActionSupport.SUCCESS;
	}

	public String zhaopianByXiangce()
	{
        Map request=(Map)ServletActionContext.getContext().get("request");
		
		String sql="from TZhaopian where del='no' and xiangceId="+xiangceId;
		List zhaopianList=zhaopianDAO.getHibernateTemplate().find(sql);
		if(zhaopianList.size()>4)
		{
			zhaopianList=zhaopianList.subList(0, 4);
		}
		request.put("zhaopianList", zhaopianList);
		
		return ActionSupport.SUCCESS;
	}

	public Integer getId()
	{
		return id;
	}


	public void setId(Integer id)
	{
		this.id = id;
	}
	public TPinglunDAO getPinglunDAO()
	{
		return pinglunDAO;
	}


	public void setPinglunDAO(TPinglunDAO pinglunDAO)
	{
		this.pinglunDAO = pinglunDAO;
	}

	public String getTitle()
	{
		return title;
	}


	public String getShijian()
	{
		return shijian;
	}


	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}


	public void setTitle(String title)
	{
		this.title = title;
	}


	public String getJieshao()
	{
		return jieshao;
	}


	public void setJieshao(String jieshao)
	{
		this.jieshao = jieshao;
	}


	public String getFujian()
	{
		return fujian;
	}


	public TXiangceDAO getXiangceDAO()
	{
		return xiangceDAO;
	}


	public void setXiangceDAO(TXiangceDAO xiangceDAO)
	{
		this.xiangceDAO = xiangceDAO;
	}


	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}


	public Integer getXiangceId()
	{
		return xiangceId;
	}


	public void setXiangceId(Integer xiangceId)
	{
		this.xiangceId = xiangceId;
	}


	public Integer getUserId()
	{
		return userId;
	}


	public void setUserId(Integer userId)
	{
		this.userId = userId;
	}


	public String getDel()
	{
		return del;
	}


	public void setDel(String del)
	{
		this.del = del;
	}


	public TZhaopianDAO getZhaopianDAO()
	{
		return zhaopianDAO;
	}


	public void setZhaopianDAO(TZhaopianDAO zhaopianDAO)
	{
		this.zhaopianDAO = zhaopianDAO;
	}

}
