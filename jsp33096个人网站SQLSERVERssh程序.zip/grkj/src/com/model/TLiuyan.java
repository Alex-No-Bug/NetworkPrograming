package com.model;

/**
 * TLiuyan entity. @author MyEclipse Persistence Tools
 */

public class TLiuyan implements java.io.Serializable
{

	private Integer id;
	private Integer fromUserId;
	private Integer toUserId;
	private String neirong;
	
	private String shijian;
	private String huifu;

	// Constructors

	/** default constructor */
	public TLiuyan()
	{
	}

	/** full constructor */
	public TLiuyan(Integer fromUserId, Integer toUserId, String neirong,
			String shijian, String huifu)
	{
		this.fromUserId = fromUserId;
		this.toUserId = toUserId;
		this.neirong = neirong;
		this.shijian = shijian;
		this.huifu = huifu;
	}

	// Property accessors

	public Integer getId()
	{
		return this.id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Integer getFromUserId()
	{
		return this.fromUserId;
	}

	public void setFromUserId(Integer fromUserId)
	{
		this.fromUserId = fromUserId;
	}

	public Integer getToUserId()
	{
		return this.toUserId;
	}

	public void setToUserId(Integer toUserId)
	{
		this.toUserId = toUserId;
	}

	public String getNeirong()
	{
		return this.neirong;
	}

	public void setNeirong(String neirong)
	{
		this.neirong = neirong;
	}

	public String getShijian()
	{
		return this.shijian;
	}

	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}

	public String getHuifu()
	{
		return this.huifu;
	}

	public void setHuifu(String huifu)
	{
		this.huifu = huifu;
	}

}