package com.model;

/**
 * TPinglun1 entity. @author MyEclipse Persistence Tools
 */

public class TPinglun implements java.io.Serializable
{

	// Fields

	private Integer id;
	private String neirong;
	private String shijian;
	private Integer zhaopianId;

	// Constructors

	/** default constructor */
	public TPinglun()
	{
	}

	/** full constructor */
	public TPinglun(String neirong, String shijian, Integer zhaopianId)
	{
		this.neirong = neirong;
		this.shijian = shijian;
		this.zhaopianId = zhaopianId;
	}

	// Property accessors

	public Integer getId()
	{
		return this.id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public String getNeirong()
	{
		return this.neirong;
	}

	public void setNeirong(String neirong)
	{
		this.neirong = neirong;
	}

	public String getShijian()
	{
		return this.shijian;
	}

	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}

	public Integer getZhaopianId()
	{
		return this.zhaopianId;
	}

	public void setZhaopianId(Integer zhaopianId)
	{
		this.zhaopianId = zhaopianId;
	}

}