package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.dao.TLiuyanDAO;
import com.model.TLiuyan;
import com.model.TUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class liuyanAction
{
	private Integer id;
	private Integer fromUserId;
	private Integer toUserId;
	private String neirong;
	
	private String shijian;
	private String huifu;
	
	private TLiuyanDAO liuyanDAO;
	
	public String liuyanAdd()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
		
		TLiuyan liuyan=new TLiuyan();
		
		//liuyan.setId(id);
		liuyan.setFromUserId(user.getUserId());
		liuyan.setToUserId(toUserId);
		liuyan.setNeirong(neirong);
		
		liuyan.setShijian(new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()));
		liuyan.setHuifu("");
		
		liuyanDAO.save(liuyan);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "�����������");
		return "msg";
	}
	
	
	public String liuyanFromMe()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
        
		String sql="from TLiuyan where fromUserId="+user.getUserId();
		List liuyanList=liuyanDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("liuyanList", liuyanList);
		
		return ActionSupport.SUCCESS;
	}
	
	
	
	public String liuyanDel()
	{
		TLiuyan liuyan=liuyanDAO.findById(id);
		liuyanDAO.delete(liuyan);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ϣɾ���ɹ�");
		return "msg";
	}
	
	
	public String liuyanToMe()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
        
		String sql="from TLiuyan where toUserId="+user.getUserId();
		List liuyanList=liuyanDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("liuyanList", liuyanList);
		
		return ActionSupport.SUCCESS;
	}


	public Integer getId()
	{
		return id;
	}


	public void setId(Integer id)
	{
		this.id = id;
	}


	public Integer getFromUserId()
	{
		return fromUserId;
	}


	public void setFromUserId(Integer fromUserId)
	{
		this.fromUserId = fromUserId;
	}


	public Integer getToUserId()
	{
		return toUserId;
	}


	public void setToUserId(Integer toUserId)
	{
		this.toUserId = toUserId;
	}


	public String getNeirong()
	{
		return neirong;
	}


	public void setNeirong(String neirong)
	{
		this.neirong = neirong;
	}


	public String getShijian()
	{
		return shijian;
	}


	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}


	public String getHuifu()
	{
		return huifu;
	}


	public void setHuifu(String huifu)
	{
		this.huifu = huifu;
	}


	public TLiuyanDAO getLiuyanDAO()
	{
		return liuyanDAO;
	}


	public void setLiuyanDAO(TLiuyanDAO liuyanDAO)
	{
		this.liuyanDAO = liuyanDAO;
	}
	
}
