package com.action;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.dao.TBowenDAO;
import com.dao.TPinglunDAO;
import com.dao.TUserDAO;
import com.dao.TXiangceDAO;
import com.dao.TZhaopianDAO;
import com.model.TBowen;
import com.model.TPinglun;
import com.model.TUser;
import com.model.TXiangce;
import com.model.TZhaopian;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class xiangceAction
{
	private Integer id;
	private String name;
	private Integer userId;
	private String del;
	
	private TXiangceDAO xiangceDAO;
	
	public String xiangceAdd()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
		
		TXiangce xiangce=new TXiangce();
		xiangce.setName(name);
		xiangce.setUserId(user.getUserId());
		xiangce.setDel("no");
		
		xiangceDAO.save(xiangce);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "����½��ɹ�");
		return "msg";
	}
	
	
	public String xiangceMine()
	{
		Map session=ActionContext.getContext().getSession();
        TUser user=(TUser)session.get("user");
        
		String sql="from TXiangce where del='no' and userId="+user.getUserId();
		List xiangceList=xiangceDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("xiangceList", xiangceList);
		
		return ActionSupport.SUCCESS;
	}
	
	
	
	public String xiangceDel()
	{
		String sql="update TXiangce set del='yes' where id="+id;
		xiangceDAO.getHibernateTemplate().bulkUpdate(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "���ɾ���ɹ�");
		return "msg";
	}
	
	
	public String xiangceMana()
	{
		Map request=(Map)ServletActionContext.getContext().get("request");
		
		String sql="from TXiangce where del='no'";
		List xiangceList=xiangceDAO.getHibernateTemplate().find(sql);
		
		request.put("xiangceList", xiangceList);
		
		return ActionSupport.SUCCESS;
	}


	public Integer getId()
	{
		return id;
	}


	public void setId(Integer id)
	{
		this.id = id;
	}


	public String getName()
	{
		return name;
	}


	public void setName(String name)
	{
		this.name = name;
	}


	public Integer getUserId()
	{
		return userId;
	}


	public void setUserId(Integer userId)
	{
		this.userId = userId;
	}


	public String getDel()
	{
		return del;
	}


	public void setDel(String del)
	{
		this.del = del;
	}


	public TXiangceDAO getXiangceDAO()
	{
		return xiangceDAO;
	}


	public void setXiangceDAO(TXiangceDAO xiangceDAO)
	{
		this.xiangceDAO = xiangceDAO;
	}
	
}
